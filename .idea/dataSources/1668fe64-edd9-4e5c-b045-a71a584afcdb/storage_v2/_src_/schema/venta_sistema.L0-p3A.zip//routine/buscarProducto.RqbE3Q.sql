create
    definer = root@localhost procedure buscarProducto(IN idProducto int, OUT pnombre varchar(50))
BEGIN
    Select nombre INTO pnombre
    FROM productos Where id_producto=idProducto;
END;

